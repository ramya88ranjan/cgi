package shopping.cart.api.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import shopping.cart.api.controller.entitty.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {
	

	
	//List<Product>  findAllByCatagory(String category);//Using Spring Data finder method
	
	
	 // @Query(value = "SELECT * FROM products  WHERE catagory = ?1", nativeQuery = true)
	 
	//List<Product>  findproductsByCatagory(String catagory);
	  
	  @Query(value = "FROM Product  WHERE catagory = :catagory")
		List<Product>  findproductsByCatagoryJPQL(@Param("catagory")String catagory);
	  
	  
	  List<Product>  findAllByProductName(String productName);
	 
	  @Query(value = "SELECT * FROM products  WHERE cart_id = ?1 and id=?2", nativeQuery = true)
	  List<Product> findproductinCart(int cart_id,int id);
	  
	  
	  
	

}
