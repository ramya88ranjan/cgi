package shopping.cart.api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import shopping.cart.api.controller.entitty.Product;
import shopping.cart.api.exception.InvalidInputException;
import shopping.cart.api.service.SearchService;

@RestController
@RequestMapping("/api")
public class SearchController {

	@Autowired
	SearchService searchService;
	private static final Logger LOGGER = LoggerFactory.getLogger(SearchController.class);

	@GetMapping("/serchbyCatagory/{catagtoty}")
	public ResponseEntity<List<Product>> SerchbyCatagory(@PathVariable("catagtoty") String catagtoty) throws Exception {
		LOGGER.info("Searching products with Catagory: " + catagtoty);

		List<Product> products = null;

		if (catagtoty == null) {
			throw new InvalidInputException("Invalid Input:Enter a valid ProductCatagory");
		}
		products = searchService.SerchbyCatagory(catagtoty);
//List<Product> prods = productRepository.findAllByCatagory("Ram");

		return new ResponseEntity<>(products, HttpStatus.OK);
	}

	@RequestMapping(value = "/searchbyName/{name}", method = RequestMethod.GET)
	public ResponseEntity<List<Product>> SerchbyName(@PathVariable("name") String name) throws Exception {
		List<Product> products = null;
		LOGGER.info("Searching products with Name: " + name);

		if (name == null) {
			throw new InvalidInputException("Invalid Input:Enter a valid Name");

		}
		products = searchService.SerchbyName(name);
		return new ResponseEntity<>(products, HttpStatus.OK);
	}

	@RequestMapping(value = "/searchbyId/{id}", method = RequestMethod.GET)
	public ResponseEntity<Product> SerchbyProductId(@PathVariable("id") int id) throws Exception {

		Product product = searchService.SerchbyId(id);

		return new ResponseEntity<>(product, HttpStatus.OK);
	}
}
