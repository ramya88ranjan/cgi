package shopping.cart.api.controller.entitty;

import javax.persistence.Entity;

@Entity
public class Apparal extends Product {
	private static final long serialVersionUID = 1L;
	private String apparalType;
	private String brand;
	private String design;
	
	
	public Apparal() {
		super();
	}


	/**
	 * @return the apparalType
	 */
	public String getApparalType() {
		return apparalType;
	}


	/**
	 * @param apparalType the apparalType to set
	 */
	public void setApparalType(String apparalType) {
		this.apparalType = apparalType;
	}


	/**
	 * @return the brand
	 */
	public String getBrand() {
		return brand;
	}


	/**
	 * @param brand the brand to set
	 */
	public void setBrand(String brand) {
		this.brand = brand;
	}


	/**
	 * @return the design
	 */
	public String getDesign() {
		return design;
	}


	/**
	 * @param design the design to set
	 */
	public void setDesign(String design) {
		this.design = design;
	}
	
	
	

}
