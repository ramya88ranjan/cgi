package shopping.cart.api.dto;

public class UpdateProdcutRequest {

	private int cartId;
	private int producttId;
	private int productQuantiy;
	/**
	 * @return the cartId
	 */
	public int getCartId() {
		return cartId;
	}
	/**
	 * @param cartId the cartId to set
	 */
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	/**
	 * @return the producttId
	 */
	public int getProducttId() {
		return producttId;
	}
	/**
	 * @param producttId the producttId to set
	 */
	public void setProducttId(int producttId) {
		this.producttId = producttId;
	}
	/**
	 * @return the productQuantiy
	 */
	public int getProductQuantiy() {
		return productQuantiy;
	}
	/**
	 * @param productQuantiy the productQuantiy to set
	 */
	public void setProductQuantiy(int productQuantiy) {
		this.productQuantiy = productQuantiy;
	}
	
	

}
