package shopping.cart.api.controller.entitty;

import javax.persistence.Entity;
@Entity
public class Book extends Product {

	
	private static final long serialVersionUID = 1L;
	
	private String gener;
	private String author;
	/**
	 * @return the gener
	 */
	public String getGener() {
		return gener;
	}
	/**
	 * @param gener the gener to set
	 */
	public void setGener(String gener) {
		this.gener = gener;
	}
	/**
	 * @return the author
	 */
	public String getAuthor() {
		return author;
	}
	/**
	 * @param author the author to set
	 */
	public void setAuthor(String author) {
		this.author = author;
	}
	/**
	 * @return the publication
	 */
	public String getPublication() {
		return publication;
	}
	/**
	 * @param publication the publication to set
	 */
	public void setPublication(String publication) {
		this.publication = publication;
	}
	private String publication;
}
