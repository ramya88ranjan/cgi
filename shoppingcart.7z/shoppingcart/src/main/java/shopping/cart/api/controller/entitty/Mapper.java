/*
 * package shopping.cart.api.controller.entitty;
 * 
 * import java.util.ArrayList; import java.util.List;
 * 
 * import javax.persistence.CascadeType; import javax.persistence.FetchType;
 * import javax.persistence.OneToMany; import javax.persistence.OneToOne;
 * 
 * import org.springframework.stereotype.Component;
 * 
 * @Component public class Mapper {
 * 
 * 
 * @OneToOne(mappedBy="cart",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
 * private User user;//= new User();
 * 
 * @OneToMany(mappedBy = "cart", cascade = CascadeType.ALL, fetch =
 * FetchType.LAZY) private List<Product> cartproducts= new ArrayList<Product>();
 *//**
	 * @return the user
	 */
/*
 * 
 * public User getUser() { return user; }
 *//**
	 * @param user the user to set
	 */
/*
 * public void setUser(User user) { this.user = user; }
 * 
 * 
 *//**
	 * @return the cartproducts
	 */
/*
 * public List<Product> getCartproducts() { return cartproducts; }
 * 
 *//**
	 * @param cartproducts the cartproducts to set
	 *//*
		 * public void setCartproducts(List<Product> cartproducts) { this.cartproducts =
		 * cartproducts; }
		 * 
		 * }
		 */