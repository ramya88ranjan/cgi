package shopping.cart.api.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import shopping.cart.api.controller.entitty.Cart;

public interface CartRepository extends JpaRepository<Cart,Integer> {

}
