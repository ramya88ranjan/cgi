package shopping.cart.api.controller.entitty;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Cart implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="cid")
	private int cartId;
	private int quantity = 0;
	/*
	 * @OneToOne(mappedBy="cart",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	 * 
	 * private User user;
	 */
	 @OneToMany(mappedBy = "cart", cascade = {CascadeType.PERSIST,CascadeType.REFRESH,CascadeType.MERGE,CascadeType.DETACH}, fetch = FetchType.LAZY)
		private List<Product> cartproducts= new ArrayList<Product>();
	

	/**
	 * @return the cartproducts
	 */
	public List<Product> getCartproducts() {
		return cartproducts;
	}

	/**
	 * @param cartproducts the cartproducts to set
	 */
	public void setCartproducts(List<Product> cartproducts) {
		this.cartproducts = cartproducts;
	}

	public Cart() {
		super();
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (cartId ^ (cartId >>> 32));
		result = prime * result + ((cartproducts == null) ? 0 : cartproducts.hashCode());
		result = prime * result + quantity;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cart other = (Cart) obj;
		if (cartId != other.cartId)
			return false;
		if (cartproducts == null) {
			if (other.cartproducts != null)
				return false;
		} else if (!cartproducts.equals(other.cartproducts))
			return false;
		if (quantity != other.quantity)
			return false;
		return true;
	}

	
	

}
