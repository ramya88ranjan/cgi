package shopping.cart.api.exception;

public class CartNotFoundException extends Exception {

	public CartNotFoundException() {
		super();
		
	}

	public CartNotFoundException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		
	}

	public CartNotFoundException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}

	public CartNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public CartNotFoundException(Throwable arg0) {
		super(arg0);
		
	}
	
	

}
