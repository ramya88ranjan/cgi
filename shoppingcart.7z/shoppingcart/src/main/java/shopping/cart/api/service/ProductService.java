package shopping.cart.api.service;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import shopping.cart.api.controller.entitty.Product;
import shopping.cart.api.exception.ServiceException;
import shopping.cart.api.exception.UserNotFoundException;
import shopping.cart.api.repos.ProductRepository;
@Service
//@Transactional//(propagation =Propagation.SUPPORTS ,readOnly = true)
public class ProductService  {
	private static final Logger LOGGER=LoggerFactory.getLogger(ProductService.class);
	@Autowired
	private ProductRepository productRepository;
	Product p;
	public Product findproduct() throws ServiceException,Exception
	{
	try {
	 Optional<Product> c= productRepository.findById(1);
	
	 if(c.isPresent())
		 p=c.get();
	 else {
		 throw new UserNotFoundException("Productnot found");
	 }
	}catch(UserNotFoundException e)
	{
		LOGGER.error("Productnot found");
		 throw new ServiceException("Product not found in service");
		
	}
	return p;
	}

}
