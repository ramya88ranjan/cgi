package shopping.cart.api.exception;

public class UserNotFoundException extends Exception {

	public UserNotFoundException(String msg) {
		super(msg);
	}

	private static final long serialVersionUID = 1L;

}
