package shopping.cart.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import shopping.cart.api.controller.entitty.Cart;
import shopping.cart.api.controller.entitty.Product;
import shopping.cart.api.dto.UpdateProdcutRequest;
import shopping.cart.api.exception.InvalidInputException;
import shopping.cart.api.repos.CartRepository;
import shopping.cart.api.repos.ProductRepository;
import shopping.cart.api.service.CartService;
import shopping.cart.api.service.ProductService;

@RestController

@RequestMapping("/api")
public class CartController {
	private static final Logger LOGGER = LoggerFactory.getLogger(ProductService.class);
	@Autowired
	ProductService ps;
	@Autowired
	CartService cs;
	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private CartRepository cRepository;

	/*
	 * @Autowired private UserRepository uRepository;
	 */

	@RequestMapping(value = "/showCart/{id}", method = RequestMethod.GET)

	public Cart showCart(@PathVariable("id") int id) throws Exception {

		Cart cart = null;
		cart = cs.ShowCart(id);

		return cart;

	}

	@RequestMapping(value = "/addProduct", method = RequestMethod.POST)

	public ResponseEntity<Cart> addProductToCart(@RequestBody UpdateProdcutRequest updateProdcut) throws Exception {

		LOGGER.info("Adding Product To CART");
		Cart cart;

		Integer poductId = updateProdcut.getProducttId();
		Integer cartId = updateProdcut.getCartId();

		cart = cs.AddProductToCart(poductId, cartId);

		return new ResponseEntity<>(cart, HttpStatus.OK);

	}

	@RequestMapping(value = "/removeAllProducts/{cartId}", method = RequestMethod.DELETE)
	public ResponseEntity<Cart> RemoveAllProducts(@PathVariable("cartId") int cartId) throws Exception {
		LOGGER.info("Removing the Products and deleting the Cart with Id:" + cartId);
		return cs.RemoveAllProducts(cartId);

	}

	@RequestMapping(value = "/removeAProduct", method = RequestMethod.DELETE)
	public ResponseEntity<Cart> removeAProduct(@RequestBody UpdateProdcutRequest updateProdcut) throws Exception {

		int productId = updateProdcut.getProducttId();
		int cartId = updateProdcut.getCartId();
		return cs.RemoveAProduct(cartId, productId);

	}

	@RequestMapping(value = "/updateProduct", method = RequestMethod.PUT)
	public ResponseEntity<Product> updateProductQuantity(@RequestBody UpdateProdcutRequest updateProdcut)
			throws Exception {

		if (updateProdcut.getProductQuantiy() < 0) {
			throw new InvalidInputException("Quantity Can not be -ve");
		}
		return cs.updateProductQuanity(updateProdcut);
	}

}
