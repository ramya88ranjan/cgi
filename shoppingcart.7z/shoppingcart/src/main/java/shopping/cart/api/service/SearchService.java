package shopping.cart.api.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import shopping.cart.api.controller.entitty.Product;
import shopping.cart.api.exception.ProductNotFoundException;
import shopping.cart.api.exception.ServiceException;
import shopping.cart.api.repos.ProductRepository;

@Service
public class SearchService {
	private static final Logger LOGGER = LoggerFactory.getLogger(SearchService.class);
	@Autowired
	private ProductRepository productRepository;

	public List<Product> SerchbyCatagory(String catagtoty) throws Exception {
		List<Product> products = null;
		try {
			products = productRepository.findproductsByCatagoryJPQL(catagtoty);
			// productRepository.findproductsByCatagory(catagtoty);

			if (0 == products.size()) {

				throw new ProductNotFoundException("No Product Found with Catagory:" + catagtoty);
			}

			System.out.println(products.size());

		} catch (ProductNotFoundException ex) {
			LOGGER.error("Error in SerchbyCatagory:No Product Found with Catagory" + catagtoty);
			throw new ServiceException(ex,"No Product Found with Catagory:");
		}

		return products;
	}

	public List<Product> SerchbyName(String name) throws Exception {
		List<Product> products = null;
		try {
			products = productRepository.findAllByProductName(name);

			if (0 == products.size()) {
				throw new ProductNotFoundException("No Product with this name exists:" + name);
			}

			System.out.println(products.size());

		} catch (ProductNotFoundException ex) {
			LOGGER.error("No Product with this name exists:" + name);
			throw new ServiceException(ex);
		}

		return products;
	}

	public Product SerchbyId(int id) throws Exception {
		Product prod = null;
		try {
			Optional<Product> product = productRepository.findById(id);

			if (product.isPresent()) {
				prod = product.get();
				return prod;
			}
			throw new ProductNotFoundException("No Product with this ID ");

		} catch (ProductNotFoundException ex) {
			LOGGER.error("No Product with this ID:" + id);
			throw new ServiceException(ex,"No Product with this ID ");
		}

	}

}
