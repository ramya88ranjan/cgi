package shopping.cart.api.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import shopping.cart.api.controller.entitty.Cart;
import shopping.cart.api.controller.entitty.Product;
import shopping.cart.api.dto.UpdateProdcutRequest;
import shopping.cart.api.exception.CartNotFoundException;
import shopping.cart.api.exception.ProductNotFoundException;
import shopping.cart.api.exception.ServiceException;
import shopping.cart.api.repos.CartRepository;

@Service
public class CartService {
	Cart cart;
	@Autowired
	SearchService searchService;
	@Autowired
	private CartRepository cRepository;
	private static final Logger LOGGER = LoggerFactory.getLogger(ProductService.class);

	public Cart ShowCart(int id) throws Exception {
		LOGGER.info("Show Products in Cart ");
		try {
			Optional<Cart> optionalCart = cRepository.findById(id);
			if (optionalCart.isPresent()) {
				cart = optionalCart.get();
				return cart;
			}
			throw new CartNotFoundException("No Cart with this ID: " + id);
		} catch (CartNotFoundException ex) {
			LOGGER.error("Error in ShowCart ");
			throw new ServiceException(ex);
		}

	}

	public Cart AddProductToCart(int productid, int cartId) throws Exception {

		cart = ShowCart(cartId);

		// Checking existing quantity
		Product p = searchService.SerchbyId(productid);
		int quantity = p.getProductQuantiy();
		List<Product> products = cart.getCartproducts();
		System.out.println("Size is :" + products.size());
		LOGGER.info("Car is empty Product exists in cart,Increase quantity");
		if (products.size() == 0 || products.contains(p) == false) {
			p.setProductQuantiy(1);
			System.out.println("no products in the cart-Add product");
			products.add(p);
			p.setCart(cart);

		}  else {
			
		LOGGER.info("Product exists in cart,Increase quantity");
		products.get(products.indexOf(p)).setProductQuantiy(quantity + 1);
		}
		return cRepository.save(cart);
	}

	public ResponseEntity<Cart> RemoveAllProducts(int cartId) throws Exception {
     System.out.println("cart id is:"+cartId);
		cart = ShowCart(cartId);

		List<Product> products = cart.getCartproducts();

		products.forEach(p -> {
			p.setCart(null);
			p.setProductQuantiy(0);
		});

		cart.setCartproducts(null);
		cRepository.delete(cart);

		return new ResponseEntity<>(cart, HttpStatus.OK);

	}

	public ResponseEntity<Cart> RemoveAProduct(int cartId, int productId) throws Exception {

		cart = ShowCart(cartId);
		Product product = searchService.SerchbyId(productId);

		List<Product> products = cart.getCartproducts();
		if (products.contains(product)) {
			products.get(products.indexOf(product)).setCart(null);
			products.get(products.indexOf(product)).setProductQuantiy(0);
			products.remove(product);
		} else {
			throw new ProductNotFoundException("Product is not Present in Cart:Cant Remove");
		}

		// cart.setCartproducts(products);
		cRepository.save(cart);
		return new ResponseEntity<>(cart, HttpStatus.OK);

	}

	public ResponseEntity<Product> updateProductQuanity(UpdateProdcutRequest updateProdcut) throws Exception {

		cart = ShowCart(updateProdcut.getCartId());
		Product product = searchService.SerchbyId(updateProdcut.getProducttId());

		List<Product> products = cart.getCartproducts();
		if (products.contains(product)) {
			products.get(products.indexOf(product)).setProductQuantiy(updateProdcut.getProductQuantiy());
		} else {
			System.out.println("Product not present in cart");
		}

		cRepository.save(cart);
		return new ResponseEntity<>(product, HttpStatus.OK);

	}

}
